 

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Listado de Aulas</h1>
    <a href="<?php echo e(route('aulas.create')); ?>" class="btn btn-primary">Crear Aula</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Capacidad</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $aulas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aula): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($aula->id); ?></td>
                <td><?php echo e($aula->nombre); ?></td>
                <td><?php echo e($aula->capacidad); ?></td>
                <td>
                    <a href="<?php echo e(route('aulas.edit', $aula)); ?>" class="btn btn-warning">Editar</a>
                    <form action="<?php echo e(route('aulas.destroy', $aula)); ?>" method="POST" style="display:inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger" type="submit">Eliminar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Usuario\Desktop\Candela Robótica\proy. del 2do Trimestre LARAVEL aula inteligente\resources\views/aulas/index.blade.php ENDPATH**/ ?>