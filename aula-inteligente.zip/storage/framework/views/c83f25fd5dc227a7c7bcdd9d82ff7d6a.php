<!-- resources/views/layouts/app.blade.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inicio</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gradient-to-br from-pink-100 via-rose-200 to-purple-200 min-h-screen flex items-center justify-center font-sans">

    
    <?php echo $__env->yieldContent('content'); ?>

</body>
</html>
<?php /**PATH D:\Usuario\Desktop\Candela Robótica\proy. del 2do Trimestre LARAVEL aula inteligente\resources\views/layouts/app.blade.php ENDPATH**/ ?>