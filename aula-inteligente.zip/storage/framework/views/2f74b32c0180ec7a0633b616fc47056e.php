<!-- resources/views/docentes/create.blade.php -->

<h1>Agregar Docente</h1>

<form action="<?php echo e(route('docentes.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <label>Nombre:</label>
    <input type="text" name="nombre" required><br>

    <label>Apellido:</label>
    <input type="text" name="apellido" required><br>

    <label>Email:</label>
    <input type="email" name="email" required><br>

    <button type="submit">Guardar</button>
</form>

<a href="<?php echo e(route('docentes.index')); ?>">⬅️ Volver</a>
<?php /**PATH D:\Usuario\Desktop\Candela Robótica\proy. del 2do Trimestre LARAVEL aula inteligente\resources\views/docentes/create.blade.php ENDPATH**/ ?>