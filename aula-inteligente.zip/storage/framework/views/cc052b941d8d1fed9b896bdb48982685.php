<!-- resources/views/home.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="text-center space-y-8">

    <h1 class="text-4xl font-bold text-pink-700 drop-shadow-md">Sistema de Gestión Escolar</h1>

    <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-4xl mx-auto">

        <!-- Botón Aulas -->
        <a href="<?php echo e(route('aulas.index')); ?>" 
           class="bg-white hover:bg-pink-100 text-pink-700 font-semibold py-6 rounded-2xl shadow-lg transition transform hover:scale-105">
            📚 Aulas
        </a>

        <!-- Botón Docentes -->
        <a href="<?php echo e(route('docentes.index')); ?>" 
           class="bg-white hover:bg-pink-100 text-pink-700 font-semibold py-6 rounded-2xl shadow-lg transition transform hover:scale-105">
            👩‍🏫 Docentes
        </a>

        <!-- Botón Elementos -->
        <a href="<?php echo e(route('elementos.index')); ?>" 
           class="bg-white hover:bg-pink-100 text-pink-700 font-semibold py-6 rounded-2xl shadow-lg transition transform hover:scale-105">
            🖥️ Elementos
        </a>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Usuario\Desktop\Candela Robótica\proy. del 2do Trimestre LARAVEL aula inteligente\resources\views/home.blade.php ENDPATH**/ ?>