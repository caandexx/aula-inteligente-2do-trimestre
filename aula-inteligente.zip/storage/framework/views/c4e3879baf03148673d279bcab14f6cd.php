<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Crear Aula</h1>
    <form action="<?php echo e(route('aulas.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>Nombre</label>
            <input type="text" name="nombre" class="form-control">
        </div>
        <div class="mb-3">
            <label>Capacidad</label>
            <input type="number" name="capacidad" class="form-control">
        </div>
        <button type="submit" class="btn btn-success">Guardar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Usuario\Desktop\Candela Robótica\proy. del 2do Trimestre LARAVEL aula inteligente\resources\views/aulas/create.blade.php ENDPATH**/ ?>